This has been cloned from the following Git repository:

[Windows Curtin Hooks](https://github.com/cloudbase/windows-curtin-hooks.git)
