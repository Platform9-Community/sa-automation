#### Extra Windows drivers
Place all extra Windows drivers under infs directory.

Please note that these drivers will be installed using
dpinst.exe which does not support scanning sub directories.

This requires all drivers to be present directly under the
infs directory.

These can include custom Windows drivers needed by certain
hardware components to function, either becuase the drivers
are not natively availble in Windows or would require extra
optimization.

